function Constant(){}

Constant.PHANTOM_ID = 3;

Constant.MODE = 2;

Constant.DEBUG_MODE = 1;
Constant.RELEASE_MODE = 2;

Constant.PLAY_MARKET = 1;
Constant.APP_STORE = 2;
Constant.RELEASE = 3;

/*
Constant.CONFIG_LINK = "http://fsv2.loc/phantom/get_config/";
Constant.TASKS_LINK = "http://fsv2.loc/phantom/get_tasks/";
Constant.RESPONSE_LINK = "http://fsv2.loc/phantom/set_response/";
*/

Constant.CONFIG_LINK = "http://gsmd.starfamous.ru/phantom/get_config/";
Constant.TASKS_LINK = "http://gsmd.starfamous.ru/phantom/get_tasks/";
Constant.RESPONSE_LINK = "http://gsmd.starfamous.ru/phantom/set_response/";


Constant.OK_STATUS = "ok";
Constant.ERR_STATUS = "err";

Constant.RUN_TIME = 180000;